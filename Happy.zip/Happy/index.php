<html>
<head>
<link href="css/aaa2.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	<div class="result" style="border: none;box-shadow: none;">
		<div class="desc" id="result-desc" align="center">
				<div style="position: relative">				
				<img id="resultImg" src="./image/index.jpg"></div>
                <form name="sex" id="sex" method="post" action="happy.php">
                <div class="radiowoman">
                <input name="sex" type="radio" value="0" checked></div>
                <div class="radioTextwoman"><input name="woman" style="text-align:center; vertical-align:middle;width:60px;font-size:15px; border:0;" type="text" value="woman" readonly></div>
                <div class="name"><input name="me" style="text-align:center; vertical-align:middle;width:150px;font-size:20px; border:1;" type="text" value="请输入姓名" onFocus="this.value='';" onBlur="if(this.value.length < 1) this.value='请输入姓名';" ></div>
          <div class="radioman">
          <input name="sex" type="radio" value="1" ></div>
          <div class="radioTextman"><input name="man" style="text-align:center; vertical-align:middle;width:60px;font-size:15px; border:0;"  type="text" value="man" readonly></div>
                <?php ?>
      <div class="todo">
        <div id="shareResult" class="facebook_share" style="width:720px" >
                    <input name="btn-success" type="submit" class="btn-success" id="btn-success" value="跟我学习" style="font-size:20px;height:40px;width:720px;"></div>
                <div class="clearfix" style="width:750px"></div>
                <div class="last"><h3 style="padding:0;margin-top:15px;font-size:18px; text-align:center;"><a class="htmlSeeMore" href="http://en.blobla.com/bla/who-is-your-most-long-time-friend?ref=pl">关注我们，更多有趣好玩的玩意</a></h3></div>
      </div></form>
        </div>
    </div>
</body>
</html>