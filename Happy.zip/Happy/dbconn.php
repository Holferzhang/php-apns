<?php
$mysql_server_name="localhost"; 
$mysql_username="root"; 
$mysql_password="eatfun123"; 
$mysql_database="test"; 

$dbconn=mysql_connect($mysql_server_name, $mysql_username, $mysql_password) or die('数据库连接失败，错误信息：'.mysql_error());
mysql_select_db("$mysql_database") or die('数据表连接错误，错误信息：'.mysql_error());
mysql_query('SET NAMES UTF8') or die('字符集设置出错'.mysql_error());
?>