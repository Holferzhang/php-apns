<?php include "dbconn.php";
$sex=$_REQUEST["sex"];
//echo $sex;
$name=$_REQUEST["me"];
//echo $name;
if($sex==1){
$id=rand(101,132);}
else {$id=rand(201,232);}
//echo $id;
$sql="select * from content where id='$id'";
$result=mysql_query($sql)or die ('数据库查询失败！');
$row=mysql_fetch_array($result)
?>
<html>
<head>
<link href="css/aaa2.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	<div class="result" style="border: none;box-shadow: none;">
		<div class="desc" id="result-desc" align="center">
				<div style="position: relative">				
					<img id="resultImg" src="image/background.jpg">
					<div id="resultText" style="font-weight: bold; position: absolute; line-height:2.0em; left: 4.17%; top: 8.23%; width: 55%; font-size: 22.5px;">
					这是 <?php echo $name;?><br>
                    <?php echo $name;?> <?php echo $row['contenttop'];?>
					<?php echo $name;?> <?php echo $row['content'];?>
                    <?php echo $name;?> <?php echo $row['contentbottom'];?>
                     <?php if($row['lenth']==6){echo $name;echo '&nbsp';echo $row['contentplus'];}?>
					大家要向 <?php echo $name;?> 学习
                    </div>
				</div>
	      <div class="todo">
                <div id="shareResult" class="facebook_share" >
                    分享朋友圈</div>
                <div class="btn btn-success">
                  重新测试
            </div>
                
                <div class="clearfix" style="width:750px"></div>
                <div class="last">
                <h3 style="padding:0;margin-top:15px;font-size:18px"><a class="htmlSeeMore" href="http://en.blobla.com/bla/who-is-your-most-long-time-friend?ref=pl">关注我们，更多有趣好玩的玩意</a></h3>
                </div>
      </div>
        </div>
    </div>
</body>
</html>